"""Double-click launcher: installs requirements if needed, then starts TDS Quest."""
import os, subprocess, sys

os.chdir(os.path.dirname(os.path.abspath(__file__)))
try:
    try:
        import streamlit, pandas, sklearn  # noqa: F401
    except ImportError:
        print("Installing required packages (one time only)...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
    print("Starting TDS Quest... your browser will open. Keep this window open while playing.")
    subprocess.call([sys.executable, "-m", "streamlit", "run", "app.py"])
except Exception as e:
    print("Error:", e)
input("\nPress Enter to close this window...")
