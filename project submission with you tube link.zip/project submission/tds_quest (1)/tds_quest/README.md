# TDS Quest
Gamified mapper: old TDS sections (IT Act 1961) -> new Section 392/393 (IT Act 2025).

Run (Windows): double-click `run.bat` or `run_app.py`. Do NOT double-click `app.py`.
Manual: `pip install -r requirements.txt` then `python -m streamlit run app.py`.
Keep the black console window open while using the app; closing it stops the app.

Files: `app.py` (game + AI classifier), `data/tds_mapping.csv` (the dataset).

IMPORTANT: rows marked "Verify" have placeholders. Fill them from the official
Income-tax Act 2025 (Section 393 table) and Income-tax Rules 2026 on incometax.gov.in,
and update `status` to "Cross-checked". Online guides disagree on payment codes,
Sl. numbers and some thresholds, so do not copy them blindly.

Mobile: open the Streamlit URL on a phone and "Add to Home Screen", or port the UI to
Flet (`flet build apk`) reusing the same CSV and logic.

Next steps: add Match-the-Pair mode, extend TRAIN phrases, add a Hindi toggle.
