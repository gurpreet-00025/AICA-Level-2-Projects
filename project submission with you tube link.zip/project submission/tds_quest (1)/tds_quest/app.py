"""TDS Quest - gamified old (1961) vs new (2025) TDS/TCS section mapper. FY 2026-27."""
import random
import pandas as pd
import streamlit as st
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

st.set_page_config(page_title="TDS Quest", page_icon="🎯", layout="centered")
df = pd.read_csv("data/tds_mapping.csv", dtype=str).fillna("")
BY_KEY = df.set_index("key")

# Training phrases for the "Ask AI" classifier - one entry per row `key` in the CSV.
TRAIN = {
    "192": ["salary to employee", "monthly payroll", "bonus paid to staff", "salary tds"],
    "193": ["interest on debentures", "interest on government securities", "interest on bonds"],
    "194A-S": ["interest to senior citizen on fixed deposit", "bank interest senior citizen"],
    "194A-O": ["interest paid on fixed deposit by bank", "post office deposit interest", "co-operative bank interest"],
    "194A-X": ["interest on loan from friend", "interest paid to relative on unsecured loan", "interest on loan from non-bank"],
    "194C": ["payment to transporter", "civil work contractor bill", "housekeeping manpower supply",
             "advertising agency payment", "labour contract payment"],
    "194D": ["insurance agent commission", "commission to lic agent"],
    "194H": ["commission to agent", "brokerage paid", "dealer commission", "commission to broker"],
    "194I(a)": ["machinery hire charges", "plant and machinery rent", "equipment rental", "crane hire",
                 "rent of machinery", "machinery rent paid", "hire of machinery", "rent of plant"],
    "194I(b)": ["office rent paid", "warehouse rent", "shop rent", "building rent", "furniture hire"],
    "194J(a)": ["software development fee", "technical services fee", "call centre services",
                "royalty for film distribution", "technical consultancy"],
    "194J(b)": ["audit fee to CA firm", "legal fees to advocate", "doctor consultation fee",
                "professional fees to consultant", "architect fees"],
    "194J(b)-D": ["director sitting fee", "director commission", "remuneration to director not salary"],
    "194": ["dividend paid to shareholders", "dividend on preference shares", "dividend payout"],
    "194DA": ["life insurance maturity proceeds", "taxable life insurance policy payout"],
    "194Q": ["purchase of raw material above 50 lakh", "goods purchased from vendor", "bulk purchase of goods"],
    "194R": ["gift to dealer", "free trip to distributor", "business perquisite benefit", "sales incentive in kind"],
    "194O": ["ecommerce operator payment to seller", "marketplace payout to seller", "amazon seller payment"],
    "194S": ["crypto sale consideration", "bitcoin transfer", "virtual digital asset purchase"],
    "194B": ["lottery winnings", "crossword puzzle prize", "card game winnings", "betting winnings"],
    "194BA": ["online game winnings", "fantasy sports winnings", "online gaming prize"],
    "194BB": ["horse race winnings", "race club prize"],
    "194G": ["lottery ticket commission", "commission on selling lottery tickets"],
    "194N-C": ["cash withdrawal from co-operative society", "cash withdrawal from co-operative bank above 3 crore"],
    "194N-O": ["cash withdrawal from bank above 1 crore", "large cash withdrawal"],
    "194EE": ["national savings scheme withdrawal", "NSS withdrawal"],
    "194T": ["partner salary", "partner remuneration", "interest to partner on capital", "partner bonus firm"],
    "195": ["payment to foreign consultant", "royalty to overseas company", "payment to non-resident",
            "fees for technical services to foreign company"],
    "194-IA": ["purchase of flat", "buying a plot of land", "purchase of immovable property"],
    "206C-A": ["sale of liquor", "alcohol sale tcs"],
    "206C-I": ["sale of tendu leaves", "tendu leaves"],
    "206C-BC": ["sale of timber", "timber forest lease"],
    "206C-D": ["forest produce sale", "other forest produce"],
    "206C-E": ["sale of scrap", "scrap dealer sale", "selling scrap"],
    "206C-J": ["sale of coal", "sale of lignite", "iron ore sale"],
    "206C-L": ["sale of motor vehicle above 10 lakh", "car sale tcs", "luxury car sale"],
    "206C-MA": ["sale of luxury watch", "sale of yacht", "sale of handbag above 10 lakh", "art piece sale"],
    "206C-T": ["foreign remittance for education", "LRS for medical treatment", "remittance for studies abroad"],
    "206C-Q": ["LRS remittance for investment abroad", "foreign remittance for gift", "LRS other purpose"],
    "206C-O1": ["overseas tour package up to 10 lakh", "foreign tour package booking"],
    "206C-O2": ["overseas tour package above 10 lakh", "expensive foreign holiday package"],
    "206C-F": ["parking lot licence", "parking lot contract"],
    "206C-G": ["toll plaza contract", "toll collection licence"],
    "206C-H": ["mine or quarry lease", "quarry licence"],
}
missing = set(df.key) - set(TRAIN)
extra = set(TRAIN) - set(df.key)
if missing or extra:
    st.error(f"CSV / TRAIN mismatch. Missing phrases for: {sorted(missing)}; unknown keys: {sorted(extra)}")
    st.stop()

@st.cache_resource
def train():
    X = [t for v in TRAIN.values() for t in v]
    y = [k for k, v in TRAIN.items() for _ in v]
    vec = TfidfVectorizer(ngram_range=(1, 2)).fit(X)
    return vec, LogisticRegression(max_iter=1000, C=20).fit(vec.transform(X), y)

def card(r):
    st.markdown(f"### {r.old_section} → {r.new_ref}")
    st.write(f"**{r.nature}**")
    c1, c2 = st.columns(2)
    c1.metric("Rate", r.rate)
    c2.metric("Threshold", r.threshold)
    c1.metric("Return form", r.return_form)
    c2.metric("Certificate", r.certificate)
    st.caption(f"Payment code: {r.payment_code}  |  What changed: {r.change_note or '-'}")
    if r.status != "Cross-checked":
        st.warning(f"Status: {r.status}. Confirm in the Act / Rules before relying on it. "
                   "Return form / certificate names are the familiar old-Act ones.")

S = st.session_state
S.setdefault("score", 0); S.setdefault("streak", 0); S.setdefault("q", None)
LEVELS = [(0, "Trainee"), (50, "Executive"), (100, "Senior"), (200, "Partner")]
level = [n for p, n in LEVELS if S.score >= p][-1]

st.title("🎯 TDS Quest")
st.caption("Income-tax Act 1961 → Income-tax Act 2025 (FY 2026-27). TDS + TCS. Learn the mapping by playing.")
st.sidebar.metric("Score", S.score); st.sidebar.metric("Streak", S.streak)
st.sidebar.write(f"Level: **{level}**")
st.sidebar.caption(f"{len(df)} sections loaded")

tab1, tab2, tab3 = st.tabs(["Reveal", "Quiz", "Ask AI"])

with tab1:
    kind = st.radio("Show", ["All", "TDS", "TCS"], horizontal=True)
    view = df if kind == "All" else df[df.old_section.str.startswith("206C") == (kind == "TCS")]
    pick = st.selectbox("Pick an old section", view.key,
                        format_func=lambda k: f"{BY_KEY.loc[k, 'old_section']}  -  {BY_KEY.loc[k, 'nature']}")
    card(df[df.key == pick].iloc[0])

QUIZ_COLS = {"rate": "TDS/TCS rate", "return_form": "return form", "threshold": "threshold",
             "new_ref": "new Act reference"}

with tab2:
    def new_q():
        col = random.choice(list(QUIZ_COLS))
        r = df.sample(1).iloc[0]
        others = [v for v in df[col].unique() if v != r[col]]
        opts = random.sample(others, min(3, len(others))) + [r[col]]
        random.shuffle(opts)
        S.q = dict(key=r.key, sec=r.old_section, nature=r.nature, col=col, ans=r[col], opts=opts, done=False)
    if S.q is None: new_q()
    q = S.q
    st.write(f"Old section **{q['sec']}** ({q['nature']}). What is the {QUIZ_COLS[q['col']]}?")
    choice = st.radio("Your answer", q["opts"], key=f"r_{q['key']}_{q['col']}", index=None)
    if st.button("Check answer") and choice and not q["done"]:
        q["done"] = True
        if choice == q["ans"]:
            S.score += 10; S.streak += 1; st.success("Correct! +10")
        else:
            S.streak = 0; st.error(f"Not quite. Answer: {q['ans']}")
    if st.button("Next question"):
        new_q(); st.rerun()

with tab3:
    text = st.text_input("Describe a payment or sale", placeholder="e.g. paid fees to a CA firm for audit")
    if text:
        vec, model = train()
        probs = model.predict_proba(vec.transform([text]))[0]
        order = probs.argsort()[::-1][:3]
        best = model.classes_[order[0]]
        st.write(f"Likely section: **{BY_KEY.loc[best, 'old_section']}** (confidence {probs[order[0]]:.0%})")
        if probs[order[0]] < 0.15:
            st.info("Low confidence - try more specific words (e.g. 'rent of machinery', 'commission to agent').")
        card(df[df.key == best].iloc[0])
        alt = [f"{BY_KEY.loc[model.classes_[i], 'old_section']} ({probs[i]:.0%})" for i in order[1:]]
        st.caption("Other possibilities: " + ", ".join(alt))
        st.caption("A learning aid built on a tiny dataset. Not tax advice.")
